package mye033.InformationRetrieval;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InformationRetrievalApplicationTests {

	@Test
	void contextLoads() {
	}

}
