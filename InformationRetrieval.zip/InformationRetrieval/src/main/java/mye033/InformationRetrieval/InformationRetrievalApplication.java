package mye033.InformationRetrieval;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InformationRetrievalApplication {

	public static void main(String[] args) {
		SpringApplication.run(InformationRetrievalApplication.class, args);
	}

}
